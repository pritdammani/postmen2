@extends('layouts.app')

@section('content')
<div class="container-fluid">
        <div class="row">
    <div class="sub-main-w3 col-sm-12">
        
    <form action="#" method="post">
            <div class="row">
            <div class="col-sm-3">


            <div class="wthree-text">
                <table><br>
                    <tr>
                        <i style="font-size:60px;" class="fa">&#xf2be;</i>
                        <h5>Create Account </h5>
                        <br>
                    </tr>
                    
                    <tr>
                        <i style="font-size:60px;color:#DDDDDD;" class="fa">&#xf0fe;</i>
                        <h5>Attach Profiles</h5>
                        <br>
                    </tr>

                    <tr>
                        <i style="font-size:60px;color:#DDDDDD;" class="fa">&#xf14a;</i>
                        <h5>Authentication of Profile </h5>
                    <br>
                    </tr>

                      <tr>
                         <i style="font-size:60px;color:#DDDDDD;" class="fa">&#xf14a;</i>
                        <h5>Start Using Tool </h5>
                        <br>
                    </tr>


                </table>    
                        
            </div>
            </div>
            <div class="col-sm-1"></div>
        <div class="col-sm-8">
            <div class="row">
            <div class="col-sm-6">
            <div class="form-style-agile">
            <label>
                    <i class=""></i>
                   
                </label>
                <input placeholder="FirstName" name="Name" type="text" required="">
            </div></div>
            <div class="col-sm-6">
            <div class="form-style-agile">
                <label>
                    <i class=""></i>
                    
                </label>
                <input placeholder="LastName" name="Name" type="text" required="">
            </div></div>
        </div>

        <div class="row">
            <div class="col-sm-6">
            <div class="form-style-agile">
                <label>
                    <i class=""></i>
                   
                </label>
                <input placeholder="Email" name="Name" type="email" required="">
            </div></div>
            <div class="col-sm-6">
            <div class="form-style-agile">
                <label>
                    <i class=""></i>
                    
                </label>
                <input placeholder="Found us on ?" type="text" name="myBrowser" required="">
<datalist id="selecting">
  <option value="Internet">
  <option value="Advertisement">
  <option value="Clients">
  <option value="Social media">
    </datalist>
            </div></div>
        </div>
        <div class="row">
            <div class="col-sm-6">
            <div class="form-style-agile">
                <label>
                    <i class=""></i>
                    
                </label>
                <input placeholder="Password" name="Password" type="password" required="">
            </div></div>
            <div class="col-sm-6">
            <div class="form-style-agile">
                <label>
                    <i class=""></i>
                    
                </label>
                <input placeholder="Confirm Password" name="Password" type="password" required="">
            </div></div>
        </div>
            <!-- checkbox -->
            <div class="wthree-text">
                <ul>
                    <li>
                        <label class="anim">
                            <input type="checkbox" class="checkbox">
                            <span>I agree terms of services</span>
                        </label>
                    </li>
                    
                </ul>
                <ul>
                    <li>
                        <label class="anim">
                            <input type="checkbox" class="checkbox">
                            <span>I agree Policy privacy</span>
                        </label>
                    </li>
                    
                </ul>
            </div>
            <!-- //checkbox -->
            <a href="http://localhost:8000/reg2">
            <input type="submit" value="Create Account"></a><br>
            <div class="wthree-text">
                <ul>
                    <li>
                            <span>Already Created Account?</span>
                        
                    
                        <a href="http://localhost:8000/login">Sign In>></a>
                    </li>
                </ul>
            </div>

        </div>

        </div>


        </form>
    </div>
    
<!-- //content signup -->

</div></div>
    <!-- Jquery -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- //Jquery -->

@endsection
