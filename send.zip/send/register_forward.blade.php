@extends('layouts.app')

@section('content')
<div class="container-fluid">
        <div class="row">
    <div class="sub-main-w3 col-sm-12">
        
    <form action="#" method="post">
            <div class="row">
            <div class="col-sm-3">


            <div class="wthree-text">
                <table><br>
                    <tr>
                        <i style="font-size:30px;color:#DDDDDD;" class="fa">&#xf2be;</i>
                        <h5>Create Account </h5>
                        <br>
                    </tr>
                    
                    <tr>
                        <i style="font-size:30px" class="fa">&#xf0fe;</i>
                        <h5>Attach Profiles</h5>
                        <br>
                    </tr>

                    <tr>
                        <i style="font-size:30px;color:#DDDDDD;" class="fa">&#xf14a;</i>
                        <h5>Authentication of Profile </h5>
                    <br>
                    </tr>

                      <tr>
                         <i style="font-size:30px;color:#DDDDDD;" class="fa">&#xf14a;</i>
                        <h5>Start Using Tool </h5>
                        <br>
                    </tr>


                </table>    
                        
            </div>
            </div>
           
        <div class="col-sm-9">
                <br><br>
     <div>
   
    <h2 style="text-align: center;font-family: lato;">Let's Connect Your First Account </h2>
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
    <a href="#"><button type="button"style="font-size: 25px"class="sa fa fa-facebook"><i>&nbsp; Facebook</i></button></a>
</div><div class="col-sm-1"></div>
<div class="col-sm-5">
<a href="#"><button type="button"style="font-size: 25px"class="sa fa fa-twitter"><i class="">&nbsp; Twitter</i></button></a><br><br>
</div>
</div>
<div class="row">
<div class="col-sm-5">
<a href="#"><button type="button"class="sa fa fa-linkedin"style="font-size: 25px"><i class="">&nbsp; LinkedIn</i></button></a><br><br>
</div>    <div class="col-sm-1"></div>
    <div class="col-sm-5">
<a href="#"><button type="button"class="sa fa fa-google"style="font-size: 23px"><i class=""><b>+ </b>&nbsp;Google Plus</i></button></a></div>
</div>
</div>
</div>


<h6>By connecting your first social media account, you shall able to schedule post and get the feel of this tool works.You can also connect accounts later from the dashboard.</h6>


  </div>

                </div>
            </div>

        </div>

        </div>


        </form>
    </div>
    
<!-- //content signup -->

</div></div>
    <!-- Jquery -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- //Jquery -->

@endsection
